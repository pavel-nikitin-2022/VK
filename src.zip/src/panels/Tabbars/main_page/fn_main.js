import React from 'react';
import { useState } from 'react';
import {
    Div,
    Button,
    List,
    Card,
    Spinner,
} from "@vkontakte/vkui";
import { Icon28LikeOutline, Icon28LikeFillRed } from '@vkontakte/icons';
import "@vkontakte/vkui/dist/vkui.css";
import './main.css';

function GifCard({ url }) {
    const [like, setActivelike] = useState(false)
    const [load, setActiveLoad] = useState(<Spinner className='Spinner' size="large" />)
    return (
        <Div>
            <Card className="Card" mode="shadow">
                {load}
                <img src={url} loading="lazy" width="100%" onLoad={() => setActiveLoad(null)}></img>
                <Div className='Div'>
                    <button onClick={() => setActivelike(!like)}>
                        {!like && <Icon28LikeOutline />}
                        {like && <Icon28LikeFillRed />}
                    </button>
                    <Button size="s" style={{ marginLeft: "30px" }} mode="tertiary">Подробнее</Button>
                </Div>
            </Card>
        </Div>
    )
}

function GifList({ list }) {
    return (
        <List width="100%">
            {list.map((url, i) => {
                return (
                    <GifCard key={i} url={url} />
                );
            })}
        </List>
    );
}

export default GifList;