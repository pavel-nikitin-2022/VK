import React from 'react';
import { useState } from 'react';
import { 
    Icon28HomeOutline,
    Icon28CubeBoxOutline,
    Icon28LocationOutline,
} from '@vkontakte/icons';
import {
    Epic,
    Tabbar,
    TabbarItem,
} from "@vkontakte/vkui";
import "@vkontakte/vkui/dist/vkui.css";
import MainPage from './Tabbars/main_page/main_page';

function Main() {
    const [simple, setSimple] = useState("main");
    return (
        <Epic activeStory="main" tabbar={
            <Tabbar>
                <TabbarItem text="главная" selected={simple === "main"} onClick={() => setSimple("main")}>
                    <Icon28HomeOutline />
                </TabbarItem>
                <TabbarItem text="навигатор" selected={simple === "navigator"} onClick={() => setSimple("navigator")}>
                    <Icon28LocationOutline />
                </TabbarItem>
                <TabbarItem text="архив" selected={simple === "archive"} onClick={() => setSimple("archive")}>
                    <Icon28CubeBoxOutline />
                </TabbarItem>
            </Tabbar>
        }>
            <MainPage id="main"/>
        </Epic>
    );
}

export default Main;