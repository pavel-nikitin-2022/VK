import React from 'react';
import {
  AdaptivityProvider,
  WebviewType,
  ConfigProvider,
  AppRoot,
  Root,
} from "@vkontakte/vkui";
import "@vkontakte/vkui/dist/vkui.css";
import Main from "./main"
import Start from "./preview"

function App() {
  return (
    <ConfigProvider webviewType={WebviewType.INTERNAL}>
      <AdaptivityProvider>
        <AppRoot>
          <Root activeView="main">
            <Start id="preview"/>
            <Main id="main"/>
          </Root>
        </AppRoot>
      </AdaptivityProvider>
    </ConfigProvider>
  );
}

export default App;
